package com.mygdx.game;

import java.io.FileNotFoundException;

public interface Function {
    double f(double x,double y, double vx, double vy) throws FileNotFoundException;

}
